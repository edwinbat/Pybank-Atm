# -*- coding: utf-8 -*-
"""
Created on Wed Sep 23 16:41:29 2026

@author: Edwin
"""

from datetime import datetime


class Transaction:
    """Bank transactions"""

    def __init__(self, phone_number, transaction_type,
                 amount, resulting_balance):
        """Initialize a transaction."""
        self.timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.phone_number = phone_number
        self.transaction_type = transaction_type
        self.amount = amount
        self.resulting_balance = resulting_balance

    def to_list(self):
        """Return transaction data as a list."""
        return [self.timestamp, self.phone_number, self.transaction_type,
                f"{self.amount:.2f}", f"{self.resulting_balance:.2f}"]
