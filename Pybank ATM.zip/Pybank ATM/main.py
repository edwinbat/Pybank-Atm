# -*- coding: utf-8 -*-
"""
Created on Wed Sep 23 16:41:29 2026

@author: Edwin
"""

import csv
import hashlib
import random
from datetime import datetime
from account import Account
from transaction import Transaction


account_file = "account_balances.txt"
transaction_file = "transactions.txt"
log_file = "log.txt"


def create_files():
    """Create CSV files for account, transaction, log, and try error"""
    try:
        with open(account_file, "w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["account_number", "phone_number", "hashed_pin",
                             "balance"])
    except FileExistsError:
        pass

    try:
        with open(transaction_file, "w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["timestamp", "phone_number", "transaction_type",
                             "amount",
                             "available_balance"])
    except FileExistsError:
        pass
    try:
        with open(log_file, "w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["timestamp", "phone_number", "event_type"])
    except FileExistsError:
        pass


def hash_pin(pin):
    """Hash a PIN using SHA-256"""
    return hashlib.sha256(pin.encode()).hexdigest()


def event_log(phone_number, event_type):
    """Write a security event to the log file."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(log_file, "a", newline="") as file:
        writer = csv.writer(file)
        writer.writerow([timestamp, phone_number, event_type])


def load_accounts():
    """storing all accounts from the account CSV file."""
    accounts = []
    with open(account_file, "r", newline="") as file:
        reader = csv.DictReader(file)
        for row in reader:
            account = Account(row["account_number"], row["phone_number"],
                              row["hashed_pin"], float(row["balance"]))
            accounts.append(account)
    return accounts


def save_accounts(accounts):
    """Save all accounts to the account CSV file."""
    with open(account_file, "w", newline="") as file:
        fieldnames = ["account_number", "phone_number", "hashed_pin",
                      "balance"]
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        for account in accounts:
            writer.writerow({"account_number": account.account_number,
                             "phone_number": account.phone_number,
                             "hashed_pin": account.hashed_pin,
                             "balance": f"{account.balance:.2f}"})


def generate_account_number(accounts):
    """Generate unique 8-digit account number."""
    existing_numbers = {
        account.account_number
        for account in accounts}
    while True:
        number = str(random.randint(10000000, 99999999))
        if number not in existing_numbers:
            return number


def user_register():
    """User register a new bank account."""
    print("\n--- Account Registration ---")
    phone = input("Enter your phone number (10 digits): ")
    if not phone.isdigit() or len(phone) != 10:
        print("Error: Phone number must be exactly 10 digits.")
        return
    accounts = load_accounts()
    for account in accounts:
        if account.phone_number == phone:
            print("Error: Phone number already registered.")
            return
    pin = input("Create a PIN (4-5 digits): ")
    if not pin.isdigit() or len(pin) not in (4, 5):
        print("Error: PIN must be 4 or 5 digits.")
        return
    confirm_pin = input("Confirm PIN: ")
    if pin != confirm_pin:
        print("Error: PINs do not match.")
        return
    account_number = generate_account_number(accounts)
    hashed_pin = hash_pin(pin)
    new_account = Account(account_number, phone, hashed_pin, 0.0)
    accounts.append(new_account)
    save_accounts(accounts)
    event_log(phone, "REGISTERED")
    print("\nRegistration successful.")
    print(f"Your account number is: {account_number}")
    print("Please save this number.")


def user_login():
    """When user logged-in"""
    print("\n--- Login ---")
    pin_attempts = 0
    while pin_attempts < 3:
        phone = input("Phone number: ")
        pin = input("PIN: ")
        accounts = load_accounts()
        logged_in_account = None

        for account in accounts:
            if account.phone_number == phone:
                logged_in_account = account
                break

        if logged_in_account is not None and logged_in_account.check_pin(pin):
            print("Login successful. Welcome back!")
            event_log(phone, "LOGIN_SUCCESS")
            atm_menu(logged_in_account)
            return

        pin_attempts += 1

        print("Invalid username or password.")

        event_log(phone, "LOGIN_FAILED")

        print(f"Attempts remaining: {3 - pin_attempts}")

    print("Too many failed attempts.")
    print("Login session terminated.")


def user_deposit(account):
    """User deposit money into an account."""
    try:
        amount = float(input("Amount to deposit: R "))
        if amount <= 0:
            print("Error: Amount must be greater than zero.")
            return
    except ValueError:
        print("Error: Please enter a valid amount.")
        return

    account.deposit(amount)

    accounts = load_accounts()

    for stored_account in accounts:
        if stored_account.account_number == account.account_number:
            stored_account.balance = account.balance
            break
    save_accounts(accounts)
    transaction = Transaction(
        account.phone_number,
        "DEPOSIT",
        amount,
        account.balance
    )

    save_transaction(transaction)
    print(f"Deposit successful. "f"New balance: R{account.balance:.2f}")


def withdrawal(account):
    """Withdraw money from an account."""
    try:
        amount = float(input("Amount to withdraw: R "))

        if amount <= 0:
            print("Error: Amount must be greater than zero.")
            return

    except ValueError:
        print("Error: Please enter a valid amount.")
        return

    if not account.withdraw(amount):
        print("Error: Insufficient funds.")
        return

    accounts = load_accounts()

    for stored_account in accounts:
        if stored_account.account_number == account.account_number:
            stored_account.balance = account.balance
            break
    save_accounts(accounts)
    transaction = Transaction(
        account.phone_number, "WITHDRAW", amount, account.balance)
    save_transaction(transaction)
    print(f"Withdrawal successful. "f"New balance: R{account.balance:.2f}")


def money_transfer(account):
    """Transfer money to another account."""
    print("\n--- EFT Transfer ---")
    recipient_number = input("Enter recipient account number (8 digits): ")

    if (not recipient_number.isdigit() or len(recipient_number) != 8):
        print("Error: Account number must be exactly 8 digits.")
        return
    if recipient_number == account.account_number:
        print("Error: You cannot transfer to your own account.")
        return

    accounts = load_accounts()

    recipient = None

    for stored_account in accounts:
        if stored_account.account_number == recipient_number:
            recipient = stored_account
            break

    if recipient is None:
        print("Error: Account not found.")
        return

    try:
        amount = float(input("Amount to transfer: R "))

        if amount <= 0:
            print("Error: Amount must be greater than zero.")
            return

    except ValueError:
        print("Error: Please enter a valid amount.")
        return

    if amount > account.balance:
        print("Error: Insufficient funds.")
        return

    account.withdraw(amount)
    recipient.deposit(amount)

    for stored_account in accounts:
        if stored_account.account_number == account.account_number:
            stored_account.balance = account.balance

        elif stored_account.account_number == recipient.account_number:
            stored_account.balance = recipient.balance

    save_accounts(accounts)

    transaction = Transaction(account.phone_number, "EFT OUT",
                              amount, account.balance)

    save_transaction(transaction)

    print(
        f"Transfer successful. "
        f"R{amount:.2f} sent to {recipient_number}."
    )

    print(f"Your new balance: R{account.balance:.2f}")


def save_transaction(transaction):
    """Save a transaction to the transaction file."""

    with open(transaction_file, "a", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(transaction.to_list())


def view_statement(account):
    """Display transactions when user login account."""
    print("\n--- Statement ---")
    with open(transaction_file, "r", newline="") as file:
        reader = csv.DictReader(file)
        found = False
        for row in reader:

            if row["phone_number"] == account.phone_number:
                found = True
                print(
                    f"{row['timestamp']} | "
                    f"{row['transaction_type']} | "
                    f"R{row['amount']} | "
                    f"Balance: R{row['available_balance']}")

        if not found:
            print("No transactions found.")


def atm_menu(account):
    """Display the menu for user login."""
    while True:
        print("\n--- Main Menu ---")
        print("1. Withdraw")
        print("2. Deposit")
        print("3. Transfer (EFT)")
        print("4. View Statement")
        print("5. Logout")

        choice = input("Select an option: ")

        if choice == "1":
            withdrawal(account)
        elif choice == "2":
            user_deposit(account)
        elif choice == "3":
            money_transfer(account)
        elif choice == "4":
            view_statement(account)
        elif choice == "5":
            print("Logged out. Stay safe.")
            return
        else:
            print("Invalid option.")


def main():
    """Start and control the ATM system."""

    create_files()
    while True:

        print("\n============================")
        print("    Welcome to PyBank ATM")
        print("============================")
        print("1. Register")
        print("2. Login")
        print("3. Exit")

        choice = input("\nSelect an option: ")

        if choice == "1":
            user_register()
        elif choice == "2":
            user_login()
        elif choice == "3":
            print("Goodbye.")
            break
        else:
            print("Invalid option.")


if __name__ == "__main__":
    main()
