# -*- coding: utf-8 -*-
"""
Created on Wed Sep 23 16:41:29 2026

@author: Edwin
"""

import hashlib


class Account:
    """Represent a bank account."""

    def __init__(self, account_number, phone_number,
                 hashed_pin, balance=0.0):
        """Initialize an account."""
        self.account_number = account_number
        self.phone_number = phone_number
        self.hashed_pin = hashed_pin
        self.balance = balance

    def deposit(self, amount):
        """Add money to the account balance."""
        self.balance += amount

    def withdraw(self, amount):
        """Withdraw money if sufficient funds are available."""
        if amount <= self.balance:
            self.balance -= amount
            return True
        return False

    def check_pin(self, pin):
        """Check if a PIN matches the stored hashed pin."""
        hashed_pin = hashlib.sha256(pin.encode()).hexdigest()
        return hashed_pin == self.hashed_pin
